#!/bin/bash
cd MainFiles
gnome-terminal -- bash -c "python3 start_miner_linux.py; exec bash"